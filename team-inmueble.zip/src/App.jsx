export default function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <h1 className="text-4xl font-bold text-center mt-10">Bienvenido a Team Inmueble</h1>
    </div>
  );
}
